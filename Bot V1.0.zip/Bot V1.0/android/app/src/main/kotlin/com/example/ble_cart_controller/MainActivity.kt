package com.example.ble_cart_controller

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

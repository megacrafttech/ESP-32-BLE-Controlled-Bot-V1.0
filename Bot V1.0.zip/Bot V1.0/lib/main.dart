// A minimal-but-complete BLE joystick controller for ESP32-Cart.
// Uses Nordic UART Service (NUS). Sends: D:<left>,<right>\n  (each -255..255)

import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

const String kDeviceName = "Bot V1.0";
// Guid() is NOT a const constructor -> use final (not const)
final Guid kNusService = Guid("6E400001-B5A3-F393-E0A9-E50E24DCCA9E");
final Guid kNusRx      = Guid("6E400002-B5A3-F393-E0A9-E50E24DCCA9E"); // write
final Guid kNusTx      = Guid("6E400003-B5A3-F393-E0A9-E50E24DCCA9E"); // notify (unused here)

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CartApp());
}

class CartApp extends StatelessWidget {
  const CartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ESP32 Cart',
      debugShowCheckedModeBanner: false, // 👈 disable banner here
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal),
      home: const DeviceScannerPage(),
    );
  }
}

class DeviceScannerPage extends StatefulWidget {
  const DeviceScannerPage({super.key});
  @override
  State<DeviceScannerPage> createState() => _DeviceScannerPageState();
}

class _DeviceScannerPageState extends State<DeviceScannerPage> {
  List<ScanResult> results = [];
  bool scanning = false;

  Future<void> _ensurePermissions() async {
    await Permission.bluetoothScan.request();
    await Permission.bluetoothConnect.request();
    await Permission.locationWhenInUse.request();
  }

  Future<void> _startScan() async {
    setState(() => scanning = true);
    results.clear();
    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 6));
    FlutterBluePlus.scanResults.listen((list) {
      setState(() {
        results = list;
      });
    });
    await Future.delayed(const Duration(seconds: 7));
    setState(() => scanning = false);
  }

  @override
  void initState() {
    super.initState();
    _ensurePermissions().then((_) => _startScan());
  }

  @override
  Widget build(BuildContext context) {
    // Avoid dead null-aware: platformName is non-null in recent flutter_blue_plus
    List<ScanResult> filtered = results.where((r) {
      final String name = r.advertisementData.advName.isNotEmpty
          ? r.advertisementData.advName
          : r.device.platformName;
      return name.contains(kDeviceName);
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Scan & Connect')),
      body: Column(
        children: [
          ListTile(
            title: const Text('Scanning'),
            trailing: scanning
                ? const CircularProgressIndicator()
                : IconButton(
                    icon: const Icon(Icons.refresh),
                    onPressed: _startScan,
                  ),
          ),
          const Divider(),
          Expanded(
            child: ListView(
              children: filtered.isEmpty
                  ? [
                      const ListTile(
                        title: Text('Looking for "Device"...'),
                        subtitle: Text('Power your device and refresh.'),
                      ),
                      ...results.map((r) {
                        final String shown =
                            r.advertisementData.advName.isNotEmpty
                                ? r.advertisementData.advName
                                : r.device.platformName;
                        return ListTile(
                          title: Text(shown),
                          subtitle: Text(r.device.remoteId.str),
                        );
                      }),
                    ]
                  : filtered.map((r) {
                      final String shown =
                          r.advertisementData.advName.isNotEmpty
                              ? r.advertisementData.advName
                              : r.device.platformName;
                      return ListTile(
                        title: Text(shown),
                        subtitle: Text(r.device.remoteId.str),
                        trailing: const Icon(Icons.bluetooth_connected),
                        onTap: () async {
                          await FlutterBluePlus.stopScan();
                          // Proper mounted check across async gap:
                          if (!mounted) return;
                          Navigator.of(context).push(MaterialPageRoute(
                            builder: (_) => ControlPage(device: r.device),
                          ));
                        },
                      );
                    }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class ControlPage extends StatefulWidget {
  final BluetoothDevice device;
  const ControlPage({super.key, required this.device});

  @override
  State<ControlPage> createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage> {
  BluetoothCharacteristic? _rx; // write
  Timer? _txTimer;
  int _maxSpeed = 180; // 0..255
  double _joyX = 0, _joyY = 0; // -1..1
  bool _connected = false;
  StreamSubscription<BluetoothConnectionState>? _connSub;

  @override
  void initState() {
    super.initState();
    _connect();
  }

  @override
  void dispose() {
    _stopSending();
    _connSub?.cancel();
    widget.device.disconnect();
    super.dispose();
  }

  Future<void> _connect() async {
    _connSub = widget.device.connectionState.listen((s) {
      setState(() => _connected = (s == BluetoothConnectionState.connected));
    });

    try {
      await widget.device.connect(timeout: const Duration(seconds: 10));
    } catch (_) {
      // Already connected or timed out
    }
    await widget.device.requestMtu(185);

    final services = await widget.device.discoverServices();
    for (final s in services) {
      if (s.uuid == kNusService) {
        for (final c in s.characteristics) {
          if (c.uuid == kNusRx) _rx = c;
        }
      }
    }
    if (_rx == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('NUS RX characteristic not found')),
      );
    }
  }

  void _startSending() {
    _txTimer?.cancel();
    _txTimer =
        Timer.periodic(const Duration(milliseconds: 50), (_) => _sendDrive());
  }

  void _stopSending() {
    _txTimer?.cancel();
    _txTimer = null;
    _sendStop();
  }

  // Differential mixing: y = forward; x = turn
  void _sendDrive() {
    if (_rx == null) return;
    final x = _joyX;
    final y = -_joyY; // up is +forward
    double l = y + x;
    double r = y - x;
    final maxMag = max(1.0, max(l.abs(), r.abs()));
    l /= maxMag;
    r /= maxMag;
    final left = (l * _maxSpeed).clamp(-255, 255).round();
    final right = (r * _maxSpeed).clamp(-255, 255).round();

    final cmd = "D:$left,$right\n";
    _rx!.write(utf8.encode(cmd), withoutResponse: true);
  }

  void _sendStop() {
    if (_rx == null) return;
    _rx!.write(utf8.encode("S\n"), withoutResponse: true);
  }

  @override
  Widget build(BuildContext context) {
    final joy = _Joystick(
      onStart: () => _startSending(),
      onEnd: () => _stopSending(),
      onChanged: (dx, dy) {
        setState(() {
          _joyX = dx;
          _joyY = dy;
        });
      },
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Controller'),
        
        actions: [
          IconButton(
            icon: const Icon(Icons.power_settings_new),
            onPressed: () async {
              await widget.device.disconnect();
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ListTile(
              leading: Icon(_connected
                  ? Icons.bluetooth_connected
                  : Icons.bluetooth_disabled),
              title: Text(widget.device.platformName),
              subtitle: Text(widget.device.remoteId.str),
              trailing: Text(
                _connected ? "CONNECTED" : "DISCONNECTED",
                style:
                    TextStyle(color: _connected ? Colors.teal : Colors.red),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: joy,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.speed),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: 255,
                    divisions: 255,
                    value: _maxSpeed.toDouble(),
                    label: 'Max: $_maxSpeed',
                    onChanged: (v) => setState(() => _maxSpeed = v.round()),
                  ),
                ),
                Text('$_maxSpeed')
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: [
                _cmdButton(Icons.arrow_upward, () {
                  _joyX = 0;
                  _joyY = -1;
                  _startSending();
                }),
                _cmdButton(Icons.stop, () {
                  _joyX = 0;
                  _joyY = 0;
                  _stopSending();
                }),
                _cmdButton(Icons.arrow_downward, () {
                  _joyX = 0;
                  _joyY = 1;
                  _startSending();
                }),
                _cmdButton(Icons.arrow_back, () {
                  _joyX = -1;
                  _joyY = 0;
                  _startSending();
                }),
                _cmdButton(Icons.arrow_forward, () {
                  _joyX = 1;
                  _joyY = 0;
                  _startSending();
                }),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _cmdButton(IconData icon, VoidCallback onPressed) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.all(16),
        shape: const CircleBorder(),
      ),
      child: Icon(icon, size: 28),
    );
  }
}

class _Joystick extends StatefulWidget {
  final void Function(double dx, double dy) onChanged; // -1..1
  final VoidCallback onStart;
  final VoidCallback onEnd;
  const _Joystick(
      {required this.onChanged, required this.onStart, required this.onEnd});

  @override
  State<_Joystick> createState() => _JoystickState();
}

class _JoystickState extends State<_Joystick> {
  Offset _pos = Offset.zero; // -1..1 space
  bool _active = false;

  void _update(Offset local, Size size) {
    final cx = size.width / 2, cy = size.height / 2;
    final dx = (local.dx - cx) / (size.width / 2);
    final dy = (local.dy - cy) / (size.height / 2);
    final v = Offset(dx, dy);
    final mag = v.distance;
    Offset clamped = v;
    if (mag > 1.0) clamped = v / mag;
    setState(() => _pos = clamped);
    widget.onChanged(clamped.dx, clamped.dy);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, bc) {
      return GestureDetector(
        onPanStart: (d) {
          _active = true;
          widget.onStart();
        },
        onPanEnd: (d) {
          _active = false;
          setState(() => _pos = Offset.zero);
          widget.onChanged(0, 0);
          widget.onEnd();
        },
        onPanCancel: () {
          _active = false;
          setState(() => _pos = Offset.zero);
          widget.onChanged(0, 0);
          widget.onEnd();
        },
        onPanUpdate: (d) {
          _update(d.localPosition, bc.biggest);
        },
        child: CustomPaint(
          painter: _JoystickPainter(_pos, _active),
        ),
      );
    });
  }
}

class _JoystickPainter extends CustomPainter {
  final Offset pos; // -1..1
  final bool active;
  _JoystickPainter(this.pos, this.active);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width, size.height) / 2 - 8;
    final knob =
        Offset(center.dx + pos.dx * radius, center.dy + pos.dy * radius);

    final bg = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    canvas.drawCircle(center, radius, bg);
    canvas.drawLine(Offset(center.dx - radius, center.dy),
        Offset(center.dx + radius, center.dy), grid);
    canvas.drawLine(Offset(center.dx, center.dy - radius),
        Offset(center.dx, center.dy + radius), grid);

    final knobPaint = Paint()..style = PaintingStyle.fill;
    canvas.drawCircle(knob, 24, knobPaint);
  }

  @override
  bool shouldRepaint(covariant _JoystickPainter oldDelegate) =>
      oldDelegate.pos != pos || oldDelegate.active != active;
}
